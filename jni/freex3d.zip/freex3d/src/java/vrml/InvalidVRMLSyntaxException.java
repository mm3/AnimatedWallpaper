package vrml;

public class InvalidVRMLSyntaxException extends Exception {
    public InvalidVRMLSyntaxException() { super(); }
    public InvalidVRMLSyntaxException(String s) { super(s); }
}
