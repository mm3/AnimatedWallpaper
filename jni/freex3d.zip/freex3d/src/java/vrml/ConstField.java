package vrml;

public abstract class ConstField extends Field
{
}
