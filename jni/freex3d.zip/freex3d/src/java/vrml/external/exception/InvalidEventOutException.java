package vrml.external.exception;

public class InvalidEventOutException extends RuntimeException
{
    public InvalidEventOutException() {
        super();
    }

    public InvalidEventOutException(String s) {
        super(s);
    }
}

