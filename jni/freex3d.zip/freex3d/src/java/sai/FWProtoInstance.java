package sai;
import org.web3d.x3d.sai.*;

public class FWProtoInstance extends FreeWRLNode implements X3DProtoInstance {
	public FWProtoInstance(FreeWRLBrowser b) {
		super(b);
	}

	public int[] getImplementationTypes() {
		return null;
	}
}
