package sai;
import org.web3d.x3d.sai.*;

public class FreeWRLComponent implements X3DComponent {

	public ExternalBrowser getBrowser() {
		return null;
	}

	public Object getImplementation() {
		return new Object();
	}

	public void shutdown() {

	}

}
