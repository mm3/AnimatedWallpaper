package org.web3d.x3d.sai;

public class NodeInUseException extends X3DException {
	public NodeInUseException() {
		super();
	}
	public NodeInUseException(String msg) {
		super(msg);
	}
}
