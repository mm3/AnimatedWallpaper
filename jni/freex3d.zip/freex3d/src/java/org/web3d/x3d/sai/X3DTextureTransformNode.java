package org.web3d.x3d.sai;

public interface X3DTextureTransformNode extends X3DAppearanceChildNode {
}
