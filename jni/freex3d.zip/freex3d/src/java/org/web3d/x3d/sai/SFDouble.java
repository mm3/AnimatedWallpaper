package org.web3d.x3d.sai;

public interface SFDouble extends X3DField {
	public double getValue();
	public void setValue(double value);
}
