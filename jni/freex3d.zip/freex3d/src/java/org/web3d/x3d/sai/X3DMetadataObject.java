package org.web3d.x3d.sai;

public interface X3DMetadataObject {
	public void setStandard(String std);
	public String getStandard();
	public void setName(String name);
	public String getName();
}
