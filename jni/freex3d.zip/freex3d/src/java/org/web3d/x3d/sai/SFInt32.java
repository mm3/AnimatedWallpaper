package org.web3d.x3d.sai;

public interface SFInt32 extends X3DField {
	public int getValue();
	public void setValue(int value);
}
