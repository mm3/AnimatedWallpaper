package org.web3d.x3d.sai;

public class InvalidBrowserException extends X3DException {
	public InvalidBrowserException() {
		super();
	}
	public InvalidBrowserException(String msg) {
		super(msg);
	}
}
