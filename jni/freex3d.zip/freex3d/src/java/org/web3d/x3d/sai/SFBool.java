package org.web3d.x3d.sai;

public interface SFBool extends X3DField {
	public boolean getValue();
	public void setValue(boolean value);
}
