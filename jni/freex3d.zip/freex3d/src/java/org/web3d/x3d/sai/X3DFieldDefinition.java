package org.web3d.x3d.sai;

public interface X3DFieldDefinition {
	public String getName();
	public int getAccessType();
	public int getFieldType();
	public String getFieldTypeString();
}
