package org.web3d.x3d.sai;

public class NoSuchBrowserException extends X3DException {
	public NoSuchBrowserException() {
		super();
	}
	public NoSuchBrowserException(String msg) {
		super(msg);
	}
}
