package org.web3d.x3d.sai;

public class InvalidExecutionContextException extends X3DException {
	public InvalidExecutionContextException() {
		super();
	}
	public InvalidExecutionContextException(String msg) {
		super(msg);
	}
}
