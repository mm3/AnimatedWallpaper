package org.web3d.x3d.sai;

public interface X3DTriggerNode extends X3DChildNode {
}
