package org.web3d.x3d.sai;

public class InsufficientCapabilitiesException extends X3DException {
	public InsufficientCapabilitiesException() {
		super();
	}
	public InsufficientCapabilitiesException(String msg) {
		super(msg);
	}
}
