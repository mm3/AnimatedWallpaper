package org.web3d.x3d.sai;

public class InvalidNodeException extends X3DException {
	public InvalidNodeException() {
		super();
	}
	public InvalidNodeException(String str) {
		super(str);
	}
}
