package org.web3d.x3d.sai;

public class InvalidProtoException extends X3DException {
	public InvalidProtoException() {
		super();
	}
	public InvalidProtoException(String msg) {
		super(msg);
	}
}
