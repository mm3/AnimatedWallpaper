package org.web3d.x3d.sai;

public class InvalidURLException extends X3DException {
	public InvalidURLException() {
		super();
	}
	public InvalidURLException(String str) {
		super(str);
	}
}
