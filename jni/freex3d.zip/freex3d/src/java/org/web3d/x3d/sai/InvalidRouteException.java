package org.web3d.x3d.sai;

public class InvalidRouteException extends X3DException {
	public InvalidRouteException() {
		super();
	}
	public InvalidRouteException(String msg) {
		super(msg);
	}
}
