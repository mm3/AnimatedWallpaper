package org.web3d.x3d.sai;

public interface SFString extends X3DField {
	public String getValue();
	public void setValue(String value);
}
