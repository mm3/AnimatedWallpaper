package org.web3d.x3d.sai;

public class InvalidFieldException extends X3DException {
	public InvalidFieldException() {
		super();
	}
	public InvalidFieldException(String msg) {
		super(msg);
	}
}
