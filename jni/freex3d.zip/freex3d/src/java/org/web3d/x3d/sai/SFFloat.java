package org.web3d.x3d.sai;

public interface SFFloat extends X3DField {
	public float getValue();
	public void setValue(float value);
}
