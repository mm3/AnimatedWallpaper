void setWindowTitle(void)
{}
void updateCursorStyle0(int cstyle)
{}
int fv_create_main_window(int argc, char *argv[])
{return 1;}
