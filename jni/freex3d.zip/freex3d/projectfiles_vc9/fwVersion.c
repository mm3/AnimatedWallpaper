    char * libFreeWRL_get_version()
	{
		return "libfreeWRL version 1.22.12";
	}
    char * freewrl_get_version()
	{
		return "freeWRL version 1.22.12";
	}
