
int initImageLoader();
int shutdownImageLoader();
int loadImage(struct textureTableIndexStruct *tti, char *fname);
